//Andrew Fenwick
// CS300Proj2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <time.h>
#include <climits>
#include <regex>
//#include <"CSCourses.h">
using namespace std;


struct Course {
    int courseId;
    string course;
    string coursePrereq;
    Course() {
        courseId = 0;
    }

};

class HashTable {

private:
    // Define structures to hold courses
    struct Node {
        Course course;
        unsigned int key;
        Node* next;

        // default constructor
        Node() {
            key = UINT_MAX;
            next = nullptr;
        }

        // initialize with a course
        Node(Course aCourse) : Node() {
            course = aCourse;
        }

        // initialize with a course and a key
        Node(Course aCourse, unsigned int aKey) : Node(aCourse) {
            key = aKey;
        }
    };

    vector<Node> nodes;

    unsigned int tableSize = 999;

    unsigned int hash(int key);

public:
    HashTable();
    HashTable(unsigned int size);
    virtual ~HashTable();
    void Insert(Course course);
    void presentCourse();
    void Remove(string courseId);
    Course Search(string courseId);
};


/**
 * Default constructor
 */
HashTable::HashTable() {

    // Initalize node structure by resizing tableSize
    nodes.resize(tableSize);

}

/**
 * Constructor for specifying size of the table
 * Use to improve efficiency of hashing algorithm
 * by reducing collisions without wasting memory.
 */
HashTable::HashTable(unsigned int size) {
    // invoke local tableSize to size with this->
    // resize nodes size
}


/**
 * Destructor
 */
HashTable::~HashTable() {
    // FIXed (2): Implement logic to free storage when class is destroyed

    // erase nodes beginning
    nodes.erase(nodes.begin());

}

unsigned int HashTable::hash(int key) {
    // FIXed (3): Implement logic to calculate a hash value
    // return key tableSize
    return key % tableSize;
}

//first set up presenting course info with any linked prereq
void presentCourse(Course course) {
    vector<string> coursePrereq = course.getCoursePrereq();
    string prereq;
    if (coursePrereq.size() == 1) {
        prereq = course.getCoursePrereq()[0];
    }
    else if (coursePrereq.size() > 1) {
        for (int i = 0; i < coursePrereq.size() - 1; i++) {
            prereq += coursePrereq[i] + ", ";
        }
        prereq += coursePrereq.back();
    }
    else {
        prereq = "No prerequisites required";
    }

    cout << course.getCourseId() << ", " << course.getCourse.Name() << ": Required Preprequisite- " << prereq << endl;

}





//now to load file with pertaining course info

void loadCourses(string csvPath, HashTable* hashTable) {
    cout << "Loading course file " << csvPath << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    // read and display header row - optional
    vector<string> header = file.getHeader();
    for (auto const& c : header) {
        cout << c << " | ";
    }
    cout << "" << endl;

    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of courses
            Course course;
            course.courseId = file[i][1];
            course.name = file[i][0];
            course.coursePrereq = file[i][8];
                 
            courseTable->Insert(course);
        }
    }
    catch (csv::Error& e) {
        std::cerr << e.what() << std::endl;
    }
}
int main()
{
 
    // Define a hash table to hold all the courses
    HashTable* courseTable;

    courseTable = new Courses();

    Course course;
    courseTable = new HashTable();

    string inputCourse, courseKey;

//now to create a menu that will use a switch the help the user enter what they want

    int choice = 0;
    while (choice != 9) {
        cout << "Welcome to the course planner" << endl;
        cout << "  1. Load Data Structure." << endl;
        cout << "  2. Print Course List." << endl;
        cout << "  3. Print Course." << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:

            cout << "Please enter file required for new course";
            cin >> inputCourse;
            loadCourses(inputCourse, courseTable);
            break;

        case 2:
            cout << "Here is a list of all courses." << endl;
                courseTable->InOrder();
            break;

        case 3:
            cout << "What course would you like to look up?" << endl;
            cin >> courseKey;
            course = courseTable->Search(courseKey);

            if (!course.getCourseId.empty()) {
                displayCourse(course);
            }
            else {
                cout << "Course Id " << courseKey << " not found." << endl;
            }


            break;
        }
        case 4:
            break;
    }

    cout << "Good bye." << endl;


    return 0;
}

